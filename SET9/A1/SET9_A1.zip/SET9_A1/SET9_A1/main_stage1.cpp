#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <random>
#include <algorithm>
#include <chrono>

class StringGenerator {
public:
    StringGenerator()
        : rng(std::chrono::steady_clock::now().time_since_epoch().count()),
          charDist(0, ALPHABET.size() - 1),
          lengthDist(10, 200) {}

    std::vector<std::string> generateRandomStrings(int count, int minLen = 10, int maxLen = 200) {
        std::vector<std::string> result;
        lengthDist = std::uniform_int_distribution<>(minLen, maxLen);
        for (int i = 0; i < count; ++i) {
            int len = lengthDist(rng);
            result.push_back(generateRandomString(len));
        }
        return result;
    }

    std::vector<std::string> generateReversed(const std::vector<std::string>& sorted) {
        std::vector<std::string> reversed = sorted;
        std::reverse(reversed.begin(), reversed.end());
        return reversed;
    }

    std::vector<std::string> generateNearlySorted(const std::vector<std::string>& sorted, int swaps) {
        std::vector<std::string> nearlySorted = sorted;
        std::uniform_int_distribution<> indexDist(0, nearlySorted.size() - 1);
        for (int i = 0; i < swaps; ++i) {
            int a = indexDist(rng);
            int b = indexDist(rng);
            std::swap(nearlySorted[a], nearlySorted[b]);
        }
        return nearlySorted;
    }

private:
    std::mt19937 rng;
    std::uniform_int_distribution<> charDist;
    std::uniform_int_distribution<> lengthDist;

    static const std::string ALPHABET;

    char getRandomChar() {
        return ALPHABET[charDist(rng)];
    }

    std::string generateRandomString(int len) {
        std::string s;
        for (int i = 0; i < len; ++i) {
            s += getRandomChar();
        }
        return s;
    }
};

const std::string StringGenerator::ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#%:;^&*()-";

void saveToFile(const std::vector<std::string>& data, const std::string& filename) {
    std::ofstream out(filename);
    for (const auto& str : data) {
        out << str << "\n";
    }
    out.close();
}

int main() {
    StringGenerator generator;

    std::vector<std::string> fullRandom3000 = generator.generateRandomStrings(3000);
    std::vector<std::string> fullSorted3000 = fullRandom3000;
    std::sort(fullSorted3000.begin(), fullSorted3000.end());
    std::vector<std::string> fullReversed3000 = generator.generateReversed(fullSorted3000);
    std::vector<std::string> fullNearlySorted3000 = generator.generateNearlySorted(fullSorted3000, 150);

    saveToFile(fullRandom3000, "random_3000.txt");
    saveToFile(fullReversed3000, "reversed_3000.txt");
    saveToFile(fullNearlySorted3000, "nearly_sorted_3000.txt");

    std::cout << "The text files have been created successfully, they are located in the 'cmake-build-debug' folder." << std::endl;

    return 0;
}
