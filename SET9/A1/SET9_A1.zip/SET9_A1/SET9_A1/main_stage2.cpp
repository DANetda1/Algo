#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "StringSortTester.h"

std::vector<std::string> loadFromFile(const std::string& filename) {
    std::ifstream in(filename);
    std::vector<std::string> data;
    std::string line;
    while (std::getline(in, line)) {
        data.push_back(line);
    }
    return data;
}

std::vector<std::string> getSubarray(const std::vector<std::string>& base, int size) {
    return std::vector<std::string>(base.begin(), base.begin() + size);
}

int main() {
    std::ofstream out("stage2_results_full.csv");
    out << "Size;QuickSort_Random;MergeSort_Random;QuickSort_Reversed;MergeSort_Reversed;QuickSort_Nearly;MergeSort_Nearly;;"
        << "Cmp_QuickSort_Random;Cmp_MergeSort_Random;Cmp_QuickSort_Reversed;Cmp_MergeSort_Reversed;Cmp_QuickSort_Nearly;Cmp_MergeSort_Nearly\n";

    std::vector<std::string> random = loadFromFile("random_3000.txt");
    std::vector<std::string> reversed = loadFromFile("reversed_3000.txt");
    std::vector<std::string> nearly = loadFromFile("nearly_sorted_3000.txt");

    for (int size = 100; size <= 3000; size += 100) {
        auto randSub = getSubarray(random, size);
        auto revSub = getSubarray(reversed, size);
        auto nearSub = getSubarray(nearly, size);

        auto qRand = StringSortTester::repeatAndAverage(StringSortTester::testQuickSort, randSub);
        auto mRand = StringSortTester::repeatAndAverage(StringSortTester::testMergeSort, randSub);
        auto qRev = StringSortTester::repeatAndAverage(StringSortTester::testQuickSort, revSub);
        auto mRev = StringSortTester::repeatAndAverage(StringSortTester::testMergeSort, revSub);
        auto qNear = StringSortTester::repeatAndAverage(StringSortTester::testQuickSort, nearSub);
        auto mNear = StringSortTester::repeatAndAverage(StringSortTester::testMergeSort, nearSub);

        std::cout << "Size: " << size << "\n";
        std::cout << "Random -> QuickSort: " << qRand.timeMs << " ms, " << qRand.comparisons << " comparisons\n";
        std::cout << "Random -> MergeSort: " << mRand.timeMs << " ms, " << mRand.comparisons << " comparisons\n";
        std::cout << "Reversed -> QuickSort: " << qRev.timeMs << " ms, " << qRev.comparisons << " comparisons\n";
        std::cout << "Reversed -> MergeSort: " << mRev.timeMs << " ms, " << mRev.comparisons << " comparisons\n";
        std::cout << "Nearly -> QuickSort: " << qNear.timeMs << " ms, " << qNear.comparisons << " comparisons\n";
        std::cout << "Nearly -> MergeSort: " << mNear.timeMs << " ms, " << mNear.comparisons << " comparisons\n";
        std::cout << "-----------------------------\n";

        out << size << ";"
            << qRand.timeMs << ";" << mRand.timeMs << ";"
            << qRev.timeMs << ";" << mRev.timeMs << ";"
            << qNear.timeMs << ";" << mNear.timeMs << ";;"
            << qRand.comparisons << ";" << mRand.comparisons << ";"
            << qRev.comparisons << ";" << mRev.comparisons << ";"
            << qNear.comparisons << ";" << mNear.comparisons << "\n";
    }

    out.close();
    std::cout << "Results saved to stage2_results_full.csv\n";
    return 0;
}
