#include "StringSortTester.h"
#include <algorithm>
#include <chrono>

int StringSortTester::charAt(const std::string& s, size_t d, size_t& counter) {
    ++counter;
    return d < s.size() ? static_cast<int>(static_cast<unsigned char>(s[d])) : -1;
}

bool StringSortTester::StringComparator::operator()(const std::string& a, const std::string& b) {
    size_t i = 0;
    while (true) {
        int ca = StringSortTester::charAt(a, i, counter);
        int cb = StringSortTester::charAt(b, i, counter);
        if (ca < cb) return true;
        if (ca > cb) return false;
        if (ca == -1) return false;
        ++i;
    }
}

SortResult StringSortTester::testQuickSort(std::vector<std::string> data) {
    size_t cmp = 0;
    StringComparator comp(cmp);
    auto st = std::chrono::high_resolution_clock::now();
    std::sort(data.begin(), data.end(), comp);
    auto en = std::chrono::high_resolution_clock::now();
    return {std::chrono::duration<double, std::milli>(en - st).count(), cmp};
}

void StringSortTester::merge(std::vector<std::string>& a, int l, int m, int r, StringComparator& comp) {
    std::vector<std::string> t;
    int i = l, j = m + 1;
    while (i <= m && j <= r) {
        if (comp(a[i], a[j])) t.push_back(a[i++]);
        else t.push_back(a[j++]);
    }
    while (i <= m) t.push_back(a[i++]);
    while (j <= r) t.push_back(a[j++]);
    for (size_t k = 0; k < t.size(); ++k) a[l + k] = std::move(t[k]);
}

void StringSortTester::mergeSort(std::vector<std::string>& a, int l, int r, StringComparator& comp) {
    if (l >= r) return;
    int m = (l + r) / 2;
    mergeSort(a, l, m, comp);
    mergeSort(a, m + 1, r, comp);
    merge(a, l, m, r, comp);
}

SortResult StringSortTester::testMergeSort(std::vector<std::string> data) {
    size_t cmp = 0;
    StringComparator comp(cmp);
    auto st = std::chrono::high_resolution_clock::now();
    mergeSort(data, 0, static_cast<int>(data.size()) - 1, comp);
    auto en = std::chrono::high_resolution_clock::now();
    return {std::chrono::duration<double, std::milli>(en - st).count(), cmp};
}

void StringSortTester::quick3sort(std::vector<std::string>& a, int lo, int hi, size_t d, size_t& counter) {
    if (hi <= lo) return;
    int lt = lo, gt = hi;
    int v = charAt(a[lo], d, counter);
    int i = lo + 1;
    while (i <= gt) {
        int t = charAt(a[i], d, counter);
        if (t < v) std::swap(a[lt++], a[i++]);
        else if (t > v) std::swap(a[i], a[gt--]);
        else ++i;
    }
    quick3sort(a, lo, lt - 1, d, counter);
    if (v >= 0) quick3sort(a, lt, gt, d + 1, counter);
    quick3sort(a, gt + 1, hi, d, counter);
}

SortResult StringSortTester::testTernaryQuickSort(std::vector<std::string> data) {
    size_t cmp = 0;
    auto st = std::chrono::high_resolution_clock::now();
    quick3sort(data, 0, static_cast<int>(data.size()) - 1, 0, cmp);
    auto en = std::chrono::high_resolution_clock::now();
    return {std::chrono::duration<double, std::milli>(en - st).count(), cmp};
}

void StringSortTester::mergeLCP(std::vector<std::string>& a, int l, int m, int r, size_t& counter) {
    std::vector<std::string> t;
    int i = l, j = m + 1;
    while (i <= m && j <= r) {
        size_t k = 0;
        while (true) {
            int ci = charAt(a[i], k, counter);
            int cj = charAt(a[j], k, counter);
            if (ci < cj) { t.push_back(a[i++]); break; }
            if (ci > cj) { t.push_back(a[j++]); break; }
            if (ci == -1) { t.push_back(a[i++]); break; }
            ++k;
        }
    }
    while (i <= m) t.push_back(a[i++]);
    while (j <= r) t.push_back(a[j++]);
    for (size_t k = 0; k < t.size(); ++k) a[l + k] = std::move(t[k]);
}

void StringSortTester::mergeSortLCP(std::vector<std::string>& a, int l, int r, size_t& counter) {
    if (l >= r) return;
    int m = (l + r) / 2;
    mergeSortLCP(a, l, m, counter);
    mergeSortLCP(a, m + 1, r, counter);
    mergeLCP(a, l, m, r, counter);
}

SortResult StringSortTester::testStringMergeSort(std::vector<std::string> data) {
    size_t cmp = 0;
    auto st = std::chrono::high_resolution_clock::now();
    mergeSortLCP(data, 0, static_cast<int>(data.size()) - 1, cmp);
    auto en = std::chrono::high_resolution_clock::now();
    return {std::chrono::duration<double, std::milli>(en - st).count(), cmp};
}

void StringSortTester::msdSort(std::vector<std::string>& a, int lo, int hi, size_t d,
                               size_t& counter, std::vector<std::string>& aux, bool useSwitch) {
    if (hi <= lo) return;
    const int R = 256;
    if (useSwitch && hi - lo + 1 < R) {
        quick3sort(a, lo, hi, d, counter);
        return;
    }
    std::vector<int> count(R + 2, 0);
    for (int i = lo; i <= hi; ++i) {
        int c = charAt(a[i], d, counter) + 1;
        ++count[c + 1];
    }
    for (int r = 0; r < R + 1; ++r) count[r + 1] += count[r];
    for (int i = lo; i <= hi; ++i) {
        int c = charAt(a[i], d, counter) + 1;
        aux[count[c]++] = std::move(a[i]);
    }
    for (int i = lo; i <= hi; ++i) a[i] = std::move(aux[i - lo]);
    for (int r = 0; r < R; ++r) {
        int start = lo + count[r];
        int end = lo + count[r + 1] - 1;
        if (start < end)
            msdSort(a, start, end, d + 1, counter, aux, useSwitch);
    }
}

SortResult StringSortTester::testMSDRadixSort(std::vector<std::string> data) {
    size_t cmp = 0;
    std::vector<std::string> aux(data.size());
    auto st = std::chrono::high_resolution_clock::now();
    msdSort(data, 0, static_cast<int>(data.size()) - 1, 0, cmp, aux, false);
    auto en = std::chrono::high_resolution_clock::now();
    return {std::chrono::duration<double, std::milli>(en - st).count(), cmp};
}

SortResult StringSortTester::testMSDRadixSortSwitch(std::vector<std::string> data) {
    size_t cmp = 0;
    std::vector<std::string> aux(data.size());
    auto st = std::chrono::high_resolution_clock::now();
    msdSort(data, 0, static_cast<int>(data.size()) - 1, 0, cmp, aux, true);
    auto en = std::chrono::high_resolution_clock::now();
    return {std::chrono::duration<double, std::milli>(en - st).count(), cmp};
}

SortResult StringSortTester::repeatAndAverage(std::function<SortResult(std::vector<std::string>)> sortFunc,
                                              const std::vector<std::string>& data,
                                              int repeats) {
    double t = 0;
    size_t c = 0;
    for (int i = 0; i < repeats; ++i) {
        std::vector<std::string> copy = data;
        SortResult r = sortFunc(copy);
        t += r.timeMs;
        c += r.comparisons;
    }
    return {t / repeats, c / repeats};
}
