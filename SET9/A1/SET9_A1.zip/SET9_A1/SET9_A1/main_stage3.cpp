#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "StringSortTester.h"

std::vector<std::string> load(const std::string& f) {
    std::ifstream in(f);
    std::vector<std::string> v;
    std::string s;
    while (std::getline(in, s)) v.push_back(s);
    return v;
}

std::vector<std::string> sub(const std::vector<std::string>& base, int n) {
    return std::vector<std::string>(base.begin(), base.begin() + n);
}

int main() {
    std::ofstream out("stage3_results_full.csv");
    out << "Size;"
        << "TSQ_Random;SM_Random;MSD_Random;MSD+SQ_Random;"
        << "TSQ_Reversed;SM_Reversed;MSD_Reversed;MSD+SQ_Reversed;"
        << "TSQ_Nearly;SM_Nearly;MSD_Nearly;MSD+SQ_Nearly;;"
        << "Cmp_TSQ_Random;Cmp_SM_Random;Cmp_MSD_Random;Cmp_MSD+SQ_Random;"
        << "Cmp_TSQ_Reversed;Cmp_SM_Reversed;Cmp_MSD_Reversed;Cmp_MSD+SQ_Reversed;"
        << "Cmp_TSQ_Nearly;Cmp_SM_Nearly;Cmp_MSD_Nearly;Cmp_MSD+SQ_Nearly\n";

    auto random = load("random_3000.txt");
    auto reversed = load("reversed_3000.txt");
    auto nearly = load("nearly_sorted_3000.txt");

    for (int size = 100; size <= 3000; size += 100) {
        auto r = sub(random, size);
        auto rev = sub(reversed, size);
        auto n = sub(nearly, size);

        auto tqR = StringSortTester::repeatAndAverage(StringSortTester::testTernaryQuickSort, r);
        auto smR = StringSortTester::repeatAndAverage(StringSortTester::testStringMergeSort, r);
        auto msdR = StringSortTester::repeatAndAverage(StringSortTester::testMSDRadixSort, r);
        auto msdSR = StringSortTester::repeatAndAverage(StringSortTester::testMSDRadixSortSwitch, r);

        auto tqRev = StringSortTester::repeatAndAverage(StringSortTester::testTernaryQuickSort, rev);
        auto smRev = StringSortTester::repeatAndAverage(StringSortTester::testStringMergeSort, rev);
        auto msdRev = StringSortTester::repeatAndAverage(StringSortTester::testMSDRadixSort, rev);
        auto msdSRev = StringSortTester::repeatAndAverage(StringSortTester::testMSDRadixSortSwitch, rev);

        auto tqN = StringSortTester::repeatAndAverage(StringSortTester::testTernaryQuickSort, n);
        auto smN = StringSortTester::repeatAndAverage(StringSortTester::testStringMergeSort, n);
        auto msdN = StringSortTester::repeatAndAverage(StringSortTester::testMSDRadixSort, n);
        auto msdSN = StringSortTester::repeatAndAverage(StringSortTester::testMSDRadixSortSwitch, n);

        std::cout << "Size " << size << "\n";
        std::cout << "Random  TSQ " << tqR.timeMs << "ms " << tqR.comparisons
                  << "  SM " << smR.timeMs << "ms " << smR.comparisons
                  << "  MSD " << msdR.timeMs << "ms " << msdR.comparisons
                  << "  MSD+SQ " << msdSR.timeMs << "ms " << msdSR.comparisons << "\n";
        std::cout << "Reverse TSQ " << tqRev.timeMs << "ms " << tqRev.comparisons
                  << "  SM " << smRev.timeMs << "ms " << smRev.comparisons
                  << "  MSD " << msdRev.timeMs << "ms " << msdRev.comparisons
                  << "  MSD+SQ " << msdSRev.timeMs << "ms " << msdSRev.comparisons << "\n";
        std::cout << "Nearly  TSQ " << tqN.timeMs << "ms " << tqN.comparisons
                  << "  SM " << smN.timeMs << "ms " << smN.comparisons
                  << "  MSD " << msdN.timeMs << "ms " << msdN.comparisons
                  << "  MSD+SQ " << msdSN.timeMs << "ms " << msdSN.comparisons << "\n";
        std::cout << "-----------------\n";

        out << size << ";"
            << tqR.timeMs << ";" << smR.timeMs << ";" << msdR.timeMs << ";" << msdSR.timeMs << ";"
            << tqRev.timeMs << ";" << smRev.timeMs << ";" << msdRev.timeMs << ";" << msdSRev.timeMs << ";"
            << tqN.timeMs << ";" << smN.timeMs << ";" << msdN.timeMs << ";" << msdSN.timeMs << ";;"
            << tqR.comparisons << ";" << smR.comparisons << ";" << msdR.comparisons << ";" << msdSR.comparisons << ";"
            << tqRev.comparisons << ";" << smRev.comparisons << ";" << msdRev.comparisons << ";" << msdSRev.comparisons << ";"
            << tqN.comparisons << ";" << smN.comparisons << ";" << msdN.comparisons << ";" << msdSN.comparisons << "\n";
    }

    out.close();
    std::cout << "Results saved to stage3_results_full.csv\n";
    return 0;
}