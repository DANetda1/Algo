#ifndef STRINGSORTTESTER_H
#define STRINGSORTTESTER_H

#include <vector>
#include <string>
#include <functional>

struct SortResult {
    double timeMs;
    size_t comparisons;
};

class StringSortTester {
public:
    static SortResult testQuickSort(std::vector<std::string> data);
    static SortResult testMergeSort(std::vector<std::string> data);
    static SortResult testTernaryQuickSort(std::vector<std::string> data);
    static SortResult testStringMergeSort(std::vector<std::string> data);
    static SortResult testMSDRadixSort(std::vector<std::string> data);
    static SortResult testMSDRadixSortSwitch(std::vector<std::string> data);
    static SortResult repeatAndAverage(std::function<SortResult(std::vector<std::string>)> sortFunc,
                                       const std::vector<std::string>& data,
                                       int repeats = 10);

private:
    static int charAt(const std::string& s, size_t d, size_t& counter);

    struct StringComparator {
        size_t& counter;
        StringComparator(size_t& c) : counter(c) {}
        bool operator()(const std::string& a, const std::string& b);
    };

    static void mergeSort(std::vector<std::string>& a, int l, int r, StringComparator& comp);
    static void merge(std::vector<std::string>& a, int l, int m, int r, StringComparator& comp);

    static void mergeSortLCP(std::vector<std::string>& a, int l, int r, size_t& counter);
    static void mergeLCP(std::vector<std::string>& a, int l, int m, int r, size_t& counter);

    static void quick3sort(std::vector<std::string>& a, int lo, int hi, size_t d, size_t& counter);

    static void msdSort(std::vector<std::string>& a, int lo, int hi, size_t d, size_t& counter,
                        std::vector<std::string>& aux, bool useSwitch);
};

#endif
